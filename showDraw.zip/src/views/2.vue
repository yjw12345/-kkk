<template>
<showproperty3 />
</template>
<script setup>
import showproperty3 from '../components/showproperty3.vue';
</script>